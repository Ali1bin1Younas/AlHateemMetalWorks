<?php $this->load->view('common/header.php'); ?>
<div class="fadeInRight animated">
  <div class="panel panel-default" style="margin-top:10px;">
    <div class="panel-heading">
      <span class="header">
        <h1>
          <img style="cursor:pointer;" class="img-responsive" onclick="window.history.back();" src="<?php echo base_url(); ?>Assets/img/al-hateem.png"/>
        </h1>
      </span>
    </div>
    <div class="panel-body">
    </div>
  </div>
</div>
          
<?php $this->load->view('common/footer'); ?>
